import java.util.Scanner;
class sum
{
        public static void main(String args [])
        {
                int a,b,c;
                Scanner sc=new Scanner(System.in);
                System.out.println("ENTER THE TWO NUMBERS");
                a= sc.nextInt();
                b= sc.nextInt();
                c=a+b;
                System.out.println("sum="+c);
        }
}
