class p
{
	public static void main(String args [])
	{
		System.out.println("ASTIK SUTARDHAR"+"\n"+"College of engineering and management , kolaghat"+"\n"+"24");
	}
}
