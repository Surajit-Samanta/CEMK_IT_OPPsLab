import java.util.*;
class fruit
{
public static void main(String args[])
{
int n=args.length,i;
Vector <String>v=new <String>Vector(n);
for(i=0;i<n;i++)
	{
		v.add(args[i]);
	}

