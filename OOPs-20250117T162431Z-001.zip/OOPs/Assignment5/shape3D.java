package shapepack;
public interface shape3D
{
public static final double PI=3.14;
public double calcVolume();
public double calcSurfaceArea();
}
 
